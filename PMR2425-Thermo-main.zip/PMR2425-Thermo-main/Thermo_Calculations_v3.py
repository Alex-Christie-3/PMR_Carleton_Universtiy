#Calculations

import Iron_Combustion_v2 as c
import Exergy_v3 as e

P_chamber=101325 #Pa
power_out=20 #kW
T_out_target=1273.15 #K
Fe_in=3 #g/s
phi=3.44394289680555 #equivalence ratio, above 1
combustion_efficiency=1
mass_fraction_FeO=0
mass_fraction_Fe3O4=1
mass_fraction_Fe2O3=0
T_in_degC=30 #degC
temp_ref=300 #K

a=c.Air_Flow(P_chamber,Fe_in,power_out,T_out_target,combustion_efficiency,mass_fraction_FeO,\
          mass_fraction_Fe3O4,mass_fraction_Fe2O3,T_in_degC)