import NISTpoly_v2_H2Omod as p

#CONSTANTS

#Air composition
O2_content=0.209476
H2O_content=0.02
other_content=.009684
N2_content=1-O2_content-H2O_content-other_content


#Molar masses (kg/mol)
M_Fe=55.845/1000
M_O=15.999/1000
M_N=14.007/1000
M_H=1.008/1000
M_C=12.011/1000
M_air=28.9647/1000
M_O2=2*M_O
M_N2=2*M_O
M_FeO=M_Fe+M_O
M_Fe3O4=(3*M_Fe)+(4*M_O)
M_Fe2O3=(2*M_Fe)+(3*M_O)
M_H2O=(2*M_H)+M_O
M_C12H23=12*M_C+23*M_H #Diesel
M_H2=2*M_H
M_NH3=M_N+3*M_H
M_CH4=M_C+4*M_H

#Enthalpies of formation for iron oxides (kJ/mol)
hf_FeO=-266.5
hf_Fe3O4=-1120.89
hf_Fe2O3=-825.5
hf_CO2=-393.52
hf_H2Og=-241.82
hf_NH3=-46.19
hf_CH4=-74.85

#Heating Values (LHV) (kJ/mol)

HV_Diesel=42600*M_C12H23

def Iron_Comb_Fe3O4(phi,T_in):
    #Assumes combustion efficiency of 1
    #Assumes only magnetite is produced
    mass_fraction_FeO=0
    mass_fraction_Fe3O4=1
    mass_fraction_Fe2O3=0
    
    T_ref=T_in #K
    
    #STOICHIOMETRIC CALCULATIONS

    Fe_in=1
    
    den=(mass_fraction_FeO/M_FeO)+(mass_fraction_Fe3O4/M_Fe3O4)+(mass_fraction_Fe2O3/M_Fe2O3)
    
    mol_fraction_FeO=(mass_fraction_FeO/M_FeO)/den
    mol_fraction_Fe3O4=(mass_fraction_Fe3O4/M_Fe3O4)/den
    mol_fraction_Fe2O3=(mass_fraction_Fe2O3/M_Fe2O3)/den
    
    oxides_out=Fe_in/(mol_fraction_FeO+(3*mol_fraction_Fe3O4)+(2*mol_fraction_Fe2O3)) #mol/s
    
    FeO_out=oxides_out*mol_fraction_FeO #mol/s
    Fe3O4_out=oxides_out*mol_fraction_Fe3O4 #mol/s
    Fe2O3_out=oxides_out*mol_fraction_Fe2O3 #mol/s
    
    air_stoich=(FeO_out+(4*Fe3O4_out)+(3*Fe2O3_out))/(2*O2_content) #mol/s
    
    air=phi*air_stoich #mol/s
    
    O2_in=air*O2_content
    N2_in=air*N2_content
    
    O2_out=((2*air*O2_content)-FeO_out-(4*Fe3O4_out)-(3*Fe2O3_out))/2 #mol/s
    N2_out=air*N2_content
    
    #Heating Value
    
    HV=-(FeO_out*hf_FeO)-(Fe3O4_out*hf_Fe3O4)-(Fe2O3_out*hf_Fe2O3) #kJ/mol Fe in
    print('Power Fe (kJ/kg Fe)',HV/M_Fe)
            
    #ENTHALPIES
    
    #Ref
    h_FeO_ref=p.Enth_FeO(T_ref)
    h_Fe3O4_ref=p.Enth_Fe3O4(T_ref)
    h_Fe2O3_ref=p.Enth_Fe2O3(T_ref)
    h_N2_ref=p.Enth_N2(T_ref)
    h_O2_ref=p.Enth_O2(T_ref)
    
    #Adiabatic Flame Temp Calculations

    left=HV
    
    #Initial Guess for Adiabatic Flame Temperature
    
    T_out=T_in
    
    
    #Initial Guess for Unknown Enthalpies
    
    h_FeO_out=p.Enth_FeO(T_out)
    h_Fe3O4_out=p.Enth_Fe3O4(T_out)
    h_Fe2O3_out=p.Enth_Fe2O3(T_out)
    
    h_O2_out=p.Enth_O2(T_out)
    h_N2_out=p.Enth_N2(T_out)
    
    right=FeO_out*(h_FeO_out-h_FeO_ref)+Fe3O4_out*(h_Fe3O4_out-h_Fe3O4_ref)+\
        Fe2O3_out*(h_Fe2O3_out-h_Fe2O3_ref)+O2_out*(h_O2_out-h_O2_ref)+N2_out*(h_N2_out-h_N2_ref)
    
    #Iterating to Adiabatic Flame Temperature
    
    diff=left-right
    counter=1
    eta=0.5
    T_out=T_out+eta*diff
    
    while diff>0.001:
        
        h_FeO_out=p.Enth_FeO(T_out)
        h_Fe3O4_out=p.Enth_Fe3O4(T_out)
        h_Fe2O3_out=p.Enth_Fe2O3(T_out)
        
        h_O2_out=p.Enth_O2(T_out)
        h_N2_out=p.Enth_N2(T_out)
        
        right=FeO_out*(h_FeO_out-h_FeO_ref)+Fe3O4_out*(h_Fe3O4_out-h_Fe3O4_ref)+\
            Fe2O3_out*(h_Fe2O3_out-h_Fe2O3_ref)+O2_out*(h_O2_out-h_O2_ref)+\
            N2_out*(h_N2_out-h_N2_ref)
        
        diff=left-right
        counter+=1
        T_out=T_out+eta*diff
    
    result_dict={'T_flame':T_out,\
                 'Fe_in':Fe_in,\
                 'O2_in':O2_in,\
                 'N2_in':N2_in,\
                 'Fe3O4_out':Fe3O4_out,\
                 'O2_out':O2_out,\
                 'N2_out':N2_out}
    
    return result_dict


def Diesel_Comb(phi,T_in):
    
    T_ref=T_in #K
    
    #STOICHIOMETRIC CALCULATIONS

    C12H23_in=1
    
    CO2_out=12*C12H23_in
    H2O_out=23*C12H23_in/2
    
    air_stoich=(2*CO2_out+H2O_out)/(2*O2_content)
    
    air=phi*air_stoich
    
    O2_in=air*O2_content
    N2_in=air*N2_content
    
    O2_out=(2*air*O2_content-2*CO2_out-H2O_out)/2
    N2_out=air*N2_content
    
    #ENTHALPIES
    
    #Ref
    h_CO2_ref=p.Enth_CO2(T_ref)
    h_H2O_ref=p.Enth_H2Og(T_ref)
    h_N2_ref=p.Enth_N2(T_ref)
    h_O2_ref=p.Enth_O2(T_ref)
    
    #Adiabatic Flame Temp Calculations

    left=HV_Diesel
    print('Power Diesel (kJ/kg Diesel)',HV_Diesel/M_C12H23)
    
    #Initial Guess for Adiabatic Flame Temperature
    
    T_out=T_in
    
    
    #Initial Guess for Unknown Enthalpies
    
    h_CO2_out=p.Enth_CO2(T_out)
    h_H2O_out=p.Enth_H2Og(T_out)
    h_O2_out=p.Enth_O2(T_out)
    h_N2_out=p.Enth_N2(T_out)
    
    right=CO2_out*(h_CO2_out-h_CO2_ref)+H2O_out*(h_H2O_out-h_H2O_ref)+\
        O2_out*(h_O2_out-h_O2_ref)+N2_out*(h_N2_out-h_N2_ref)
    
    #Iterating to Adiabatic Flame Temperature
    
    diff=left-right
    counter=1
    eta=0.01
    T_out=T_out+eta*diff
    
    while diff>0.001:
        
        h_CO2_out=p.Enth_CO2(T_out)
        h_H2O_out=p.Enth_H2Og(T_out)
        h_O2_out=p.Enth_O2(T_out)
        h_N2_out=p.Enth_N2(T_out)
        
        right=CO2_out*(h_CO2_out-h_CO2_ref)+H2O_out*(h_H2O_out-h_H2O_ref)+\
            O2_out*(h_O2_out-h_O2_ref)+N2_out*(h_N2_out-h_N2_ref)
        
        diff=left-right
        counter+=1
        T_out=T_out+eta*diff
    
    result_dict={'T_flame':T_out,\
                 'C12H23_in':C12H23_in,\
                 'O2_in':O2_in,\
                 'N2_in':N2_in,\
                 'CO2_out':CO2_out,\
                 'H2O_out':H2O_out,\
                 'O2_out':O2_out,\
                 'N2_out':N2_out}
    
    return result_dict


def Coal_Comb(phi,T_in):
    
    T_ref=T_in #K
    
    #STOICHIOMETRIC CALCULATIONS

    C_in=1
    
    CO2_out=C_in
    
    air_stoich=CO2_out/O2_content
    
    air=phi*air_stoich
    
    O2_in=air*O2_content
    N2_in=air*N2_content
    
    O2_out=air*O2_content-CO2_out
    N2_out=air*N2_content
    
    #Heating Value
    
    HV=-(CO2_out*hf_CO2) #kJ/mol C in
    print('Power C (kJ/kg C)',HV/M_C)
    
    #ENTHALPIES
    
    #Ref
    h_CO2_ref=p.Enth_CO2(T_ref)
    h_N2_ref=p.Enth_N2(T_ref)
    h_O2_ref=p.Enth_O2(T_ref)
    
    #Adiabatic Flame Temp Calculations

    left=HV
    
    #Initial Guess for Adiabatic Flame Temperature
    
    T_out=T_in
    
    
    #Initial Guess for Unknown Enthalpies
    
    h_CO2_out=p.Enth_CO2(T_out)
    h_O2_out=p.Enth_O2(T_out)
    h_N2_out=p.Enth_N2(T_out)
    
    right=CO2_out*(h_CO2_out-h_CO2_ref)+O2_out*(h_O2_out-h_O2_ref)+\
        N2_out*(h_N2_out-h_N2_ref)
    
    #Iterating to Adiabatic Flame Temperature
    
    diff=left-right
    counter=1
    eta=0.01
    T_out=T_out+eta*diff
    
    while diff>0.001:
        
        h_CO2_out=p.Enth_CO2(T_out)
        h_O2_out=p.Enth_O2(T_out)
        h_N2_out=p.Enth_N2(T_out)
        
        right=CO2_out*(h_CO2_out-h_CO2_ref)+O2_out*(h_O2_out-h_O2_ref)+\
            N2_out*(h_N2_out-h_N2_ref)
        
        diff=left-right
        counter+=1
        T_out=T_out+eta*diff
    
    result_dict={'T_flame':T_out,\
                 'C_in':C_in,\
                 'O2_in':O2_in,\
                 'N2_in':N2_in,\
                 'CO2_out':CO2_out,\
                 'O2_out':O2_out,\
                 'N2_out':N2_out}

    return result_dict

def Hydrogen_Comb(phi,T_in):
    
    T_ref=T_in #K
    
    #STOICHIOMETRIC CALCULATIONS

    H2_in=1
    
    H2O_out=H2_in
    
    air_stoich=H2O_out/(2*O2_content)
    
    air=phi*air_stoich
    
    O2_in=air*O2_content
    N2_in=air*N2_content
    
    O2_out=(2*air*O2_content-H2O_out)/2
    N2_out=air*N2_content
    
    #Heating Value
    
    HV=-(H2O_out*hf_H2Og) #kJ/mol H2 in
    print('Power H2 (kJ/kg H2)',HV/M_H2)
    
    #ENTHALPIES
    
    #Ref
    h_H2O_ref=p.Enth_H2Og(T_ref)
    h_N2_ref=p.Enth_N2(T_ref)
    h_O2_ref=p.Enth_O2(T_ref)
    
    #Adiabatic Flame Temp Calculations

    left=HV
    
    #Initial Guess for Adiabatic Flame Temperature
    
    T_out=T_in
    
    
    #Initial Guess for Unknown Enthalpies
    
    h_H2O_out=p.Enth_H2Og(T_out)
    h_O2_out=p.Enth_O2(T_out)
    h_N2_out=p.Enth_N2(T_out)
    
    right=H2O_out*(h_H2O_out-h_H2O_ref)+O2_out*(h_O2_out-h_O2_ref)+\
        N2_out*(h_N2_out-h_N2_ref)
    
    #Iterating to Adiabatic Flame Temperature
    
    diff=left-right
    counter=1
    eta=0.01
    T_out=T_out+eta*diff
    
    while diff>0.001:
        
        h_H2O_out=p.Enth_H2Og(T_out)
        h_O2_out=p.Enth_O2(T_out)
        h_N2_out=p.Enth_N2(T_out)
        
        right=H2O_out*(h_H2O_out-h_H2O_ref)+O2_out*(h_O2_out-h_O2_ref)+\
            N2_out*(h_N2_out-h_N2_ref)
        
        diff=left-right
        counter+=1
        T_out=T_out+eta*diff
    
    result_dict={'T_flame':T_out,\
                 'H2_in':H2_in,\
                 'O2_in':O2_in,\
                 'N2_in':N2_in,\
                 'H2O_out':H2O_out,\
                 'O2_out':O2_out,\
                 'N2_out':N2_out}

    return result_dict


def Ammonia_Comb(phi,T_in):
    
    T_ref=T_in #K
    
    #STOICHIOMETRIC CALCULATIONS

    NH3_in=1
    
    H2O_out=3*NH3_in/2
    
    air_stoich=H2O_out/(2*O2_content)
    
    air=phi*air_stoich
    
    O2_in=air*O2_content
    N2_in=air*N2_content
    
    O2_out=(2*air*O2_content-H2O_out)/2
    N2_out=(NH3_in+2*air*N2_content)/2
    
    #Heating Value
    
    HV=(NH3_in*hf_NH3)-(H2O_out*hf_H2Og) #kJ/mol NH3 in
    print('Power NH3 (kJ/kg NH3)',HV/M_NH3)
    
    #ENTHALPIES
    
    #Ref
    h_H2O_ref=p.Enth_H2Og(T_ref)
    h_N2_ref=p.Enth_N2(T_ref)
    h_O2_ref=p.Enth_O2(T_ref)
    
    #Adiabatic Flame Temp Calculations

    left=HV
    
    #Initial Guess for Adiabatic Flame Temperature
    
    T_out=T_in
    
    
    #Initial Guess for Unknown Enthalpies
    
    h_H2O_out=p.Enth_H2Og(T_out)
    h_O2_out=p.Enth_O2(T_out)
    h_N2_out=p.Enth_N2(T_out)
    
    right=H2O_out*(h_H2O_out-h_H2O_ref)+O2_out*(h_O2_out-h_O2_ref)+\
        N2_out*(h_N2_out-h_N2_ref)
    
    #Iterating to Adiabatic Flame Temperature
    
    diff=left-right
    counter=1
    eta=0.01
    T_out=T_out+eta*diff
    
    while diff>0.001:
        
        h_H2O_out=p.Enth_H2Og(T_out)
        h_O2_out=p.Enth_O2(T_out)
        h_N2_out=p.Enth_N2(T_out)
        
        right=H2O_out*(h_H2O_out-h_H2O_ref)+O2_out*(h_O2_out-h_O2_ref)+\
            N2_out*(h_N2_out-h_N2_ref)
        
        diff=left-right
        counter+=1
        T_out=T_out+eta*diff
    
    result_dict={'T_flame':T_out,\
                 'NH3_in':NH3_in,\
                 'O2_in':O2_in,\
                 'N2_in':N2_in,\
                 'H2O_out':H2O_out,\
                 'O2_out':O2_out,\
                 'N2_out':N2_out}

    return result_dict


def Methane_Comb(phi,T_in):
    
    T_ref=T_in #K
    
    #STOICHIOMETRIC CALCULATIONS

    CH4_in=1
    
    CO2_out=CH4_in
    H2O_out=2*CH4_in
    
    air_stoich=(2*CO2_out+H2O_out)/(2*O2_content)
    
    air=phi*air_stoich
    
    O2_in=air*O2_content
    N2_in=air*N2_content
    
    O2_out=(2*air*O2_content-2*CO2_out-H2O_out)/2
    N2_out=air*N2_content
    
    #Heating Value
    
    HV=(CH4_in*hf_CH4)-(CO2_out*hf_CO2)-(H2O_out*hf_H2Og) #kJ/mol CH4 in
    print('Power CH4 (kJ/kg CH4)',HV/M_CH4)
    
    #ENTHALPIES
    
    #Ref
    h_CO2_ref=p.Enth_CO2(T_ref)
    h_H2O_ref=p.Enth_H2Og(T_ref)
    h_N2_ref=p.Enth_N2(T_ref)
    h_O2_ref=p.Enth_O2(T_ref)
    
    #Adiabatic Flame Temp Calculations

    left=HV
    
    #Initial Guess for Adiabatic Flame Temperature
    
    T_out=T_in
    
    
    #Initial Guess for Unknown Enthalpies
    
    h_CO2_out=p.Enth_CO2(T_out)
    h_H2O_out=p.Enth_H2Og(T_out)
    h_O2_out=p.Enth_O2(T_out)
    h_N2_out=p.Enth_N2(T_out)
    
    right=CO2_out*(h_CO2_out-h_CO2_ref)+H2O_out*(h_H2O_out-h_H2O_ref)+\
        O2_out*(h_O2_out-h_O2_ref)+N2_out*(h_N2_out-h_N2_ref)
    
    #Iterating to Adiabatic Flame Temperature
    
    diff=left-right
    counter=1
    eta=0.01
    T_out=T_out+eta*diff
    
    while diff>0.001:
        
        h_CO2_out=p.Enth_CO2(T_out)
        h_H2O_out=p.Enth_H2Og(T_out)
        h_O2_out=p.Enth_O2(T_out)
        h_N2_out=p.Enth_N2(T_out)
        
        right=CO2_out*(h_CO2_out-h_CO2_ref)+H2O_out*(h_H2O_out-h_H2O_ref)+\
            O2_out*(h_O2_out-h_O2_ref)+N2_out*(h_N2_out-h_N2_ref)
        
        diff=left-right
        counter+=1
        T_out=T_out+eta*diff
    
    result_dict={'T_flame':T_out,\
                 'CH4_in':CH4_in,\
                 'O2_in':O2_in,\
                 'N2_in':N2_in,\
                 'CO2_out':CO2_out,\
                 'H2O_out':H2O_out,\
                 'O2_out':O2_out,\
                 'N2_out':N2_out}
    
    return result_dict

'''
a=Iron_Comb_Fe3O4(3,298)
print(a['T_flame'])

b=Diesel_Comb(3,298)
print(b['T_flame'])

c=Coal_Comb(3,298)
print(c['T_flame'])

d=Hydrogen_Comb(3,298)
print(d['T_flame'])

e=Ammonia_Comb(3,298)
print(e['T_flame'])

f=Methane_Comb(3,298)
print(f['T_flame'])
'''