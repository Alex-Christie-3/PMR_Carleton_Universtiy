import math as m


#Enthalpy

def Enth_Fe(Temperature):
    if Temperature <298:
        raise Exception('Fe temp too low')
    elif 298<=Temperature<700:# in range(298, 700):#298-699
        FeConstants=[Temperature,18.42868,24.64301,-8.91372,9.664706,-0.012643,-6.573022,42.51488,0]
    elif 700<=Temperature<1042:
        FeConstants=[Temperature,-57767.65,137919.7,-122773.2,38682.42,3993.08,24078.67,-87364.01,0]
    elif 1042<=Temperature<1100:
        FeConstants=[Temperature,-325.8859,28.92876,0,0,411.9629,745.8231,241.8766,0]
    elif 1100<=Temperature<1809:
        FeConstants=[Temperature,-776.7387,919.4005,-383.7184,57.08148,242.1369,697.6234,-558.3674,0]
    else:
        raise Exception('Fe temp too high')
    T,A,B,C,D,E,F,G,H = FeConstants
    t = T/1000
    h = A*t + B*(t**2)/2 + C*(t**3)/3 + D*(t**4)/4 - E/t + F - H
    return h #kJ/mol


def Enth_FeO(Temperature):
    if Temperature <298:
        raise Exception('FeO temp too low')
    elif 298<=Temperature<1650:
        FeOconstants=[Temperature,45.7512,18.78553,-5.952201,0.852779,-0.081265,-286.7429,110.312,-272.0441]
    elif 1650<=Temperature<5000:
        FeOconstants=[Temperature,68.1992,-55.01232,0.0000000001195227,-21.64302,-40.9268,-281.4326,137.8377,-249.5321]        
    else:
        raise Exception('FeO temp too high')
    T,A,B,C,D,E,F,G,H = FeOconstants
    t = T/1000
    h = A*t + B*(t**2)/2 + C*(t**3)/3 + D*(t**4)/4 - E/t + F - H
    return h #kJ/mol


def Enth_Fe3O4(Temperature):
    if Temperature <298:
        raise Exception('Fe3O4 temp too low')
    elif 298<=Temperature<900:
        Fe3O4constants=[Temperature,104.2096,178.5108,10.6151,1.132534,-0.994202,-1163.336,212.0585,-1120.894]
    elif 900<=Temperature<3000:
        Fe3O4constants=[Temperature,200.832,0.0000001586435,-0.00000006661682,0.000000009452452,0.0000000318602,\
                     -1174.135,388.079,-1120.894]        
    else:
        raise Exception('Fe3O4 temp too high')
    T,A,B,C,D,E,F,G,H = Fe3O4constants
    t = T/1000
    h = A*t + B*(t**2)/2 + C*(t**3)/3 + D*(t**4)/4 - E/t + F - H
    return h #kJ/mol


def Enth_Fe2O3(Temperature):
    if Temperature <298:
        raise Exception('Fe2O3 temp too low')
    elif 298<=Temperature<950:
        Fe2O3constants=[Temperature,93.43834,108.3577,-50.86447,25.58683,-1.61133,-863.2094,161.0719,-825.5032]
    elif 950<=Temperature<1050:
        Fe2O3constants=[Temperature,150.624,0,0,0,0,-875.6066,252.8814,-825.5032]
    elif 1050<=Temperature<2500:
        Fe2O3constants=[Temperature,110.9362,32.04714,-9.192333,0.901506,5.433677,-843.1471,228.3548,-825.5032]        
    else:
        raise Exception('Fe2O3 temp too high')
    T,A,B,C,D,E,F,G,H = Fe2O3constants
    t = T/1000
    h = A*t + B*(t**2)/2 + C*(t**3)/3 + D*(t**4)/4 - E/t + F - H
    return h #kJ/mol


def Enth_O2(Temperature):
    if Temperature <100:
        raise Exception('O2 temp too low')
    elif 100<=Temperature<700:
        O2constants=[Temperature,31.32234,-20.23531,57.86644,-36.50624,-0.007374,-8.903471,246.7945,0]
    elif 700<=Temperature<2000:
        O2constants=[Temperature,30.03235,8.772972,-3.988133,0.788313,-0.741599,-11.32468,236.1663,0]
    elif 2000<=Temperature<6000:
        O2constants=[Temperature,20.91111,10.72071,-2.020498,0.146449,9.245722,5.337651,237.6185,0]        
    else:
        raise Exception('O2 temp too high')
    T,A,B,C,D,E,F,G,H = O2constants
    t = T/1000
    h = A*t + B*(t**2)/2 + C*(t**3)/3 + D*(t**4)/4 - E/t + F - H
    return h #kJ/mol

def Enth_N2(Temperature):
    if Temperature <100:
        raise Exception('N2 temp too low')
    elif 100<=Temperature<500:
        N2constants=[Temperature,28.98641,1.853978,-9.647459,16.63537,0.000117,-8.671914,226.4168,0]
    elif 500<=Temperature<2000:
        N2constants=[Temperature,19.50583,19.88705,-8.598535,1.369784,0.527601,-4.935202,212.39,0]
    elif 2000<=Temperature<6000:
        N2constants=[Temperature,35.51872,1.128728,-0.196103,0.014662,-4.55376,-18.97091,224.981,0]        
    else:
        raise Exception('N2 temp too high')
    T,A,B,C,D,E,F,G,H = N2constants
    t = T/1000
    h = A*t + B*(t**2)/2 + C*(t**3)/3 + D*(t**4)/4 - E/t + F - H
    return h #kJ/mol


def Enth_H2(Temperature):
    if Temperature <298:
        raise Exception('H2 temp too low')
    elif 298<=Temperature<1000:
        H2constants=[Temperature,33.066178,-11.363417,11.432816,-2.772874,-0.158558,-9.980797,172.707974,0]
    elif 1000<=Temperature<2500:
        H2constants=[Temperature,18.563083,12.257357,-2.859786,0.268238,1.97799,-1.147438,156.288133,0]        
    elif 2500<=Temperature<6000:
        H2constants=[Temperature,43.41356,-4.293079,1.272428,-0.096876,-20.533862,-38.515158,162.081354,0]
    else:
        raise Exception('H2 temp too high')
    T,A,B,C,D,E,F,G,H = H2constants
    t = T/1000
    h = A*t + B*(t**2)/2 + C*(t**3)/3 + D*(t**4)/4 - E/t + F - H
    return h #kJ/mol


def Enth_H2Og(Temperature):
    if Temperature <298:
        raise Exception('H2Og (steam) temp too low')
    elif 298<=Temperature<1700:
        H2OgConstants=[Temperature,30.092,6.832514,6.793435,-2.53448,0.082139,-250.881,223.3967,-241.8264]
    elif 1700<=Temperature<6000:
        H2OgConstants=[Temperature,41.96426,8.622053,-1.49978,0.098119,-11.15764,-272.1797,219.7809,-241.8264]        
    else:
        raise Exception('H2Og (stream) temp too high')
    T,A,B,C,D,E,F,G,H = H2OgConstants
    t = T/1000
    h = A*t + B*(t**2)/2 + C*(t**3)/3 + D*(t**4)/4 - E/t + F - H
    return h #kJ/mol

def Enth_CH4(Temperature):
    if Temperature <298:
        raise Exception('CH4 temp too low')
    elif 298<=Temperature<1300:
        CH4constants=[Temperature,-0.703029,108.4773,-42.52157,5.862788,0.678565,-76.84376,158.7163,-74.8731]
    elif 1300<=Temperature<6000:
        CH4constants=[Temperature,85.81217,11.26467,-2.114146,0.13819,-26.42221,-153.5327,224.4143,-74.8731]
    else:
        raise Exception('CH4 temp too high')
    T,A,B,C,D,E,F,G,H = CH4constants
    t = T/1000
    h = A*t + B*(t**2)/2 + C*(t**3)/3 + D*(t**4)/4 - E/t + F - H
    return h #kJ/mol


def Enth_CO2(Temperature):
    if Temperature <298:
        raise Exception('CO2 temp too low')
    elif 298<=Temperature<1200:
        CO2constants=[Temperature,24.99735,55.18696,-33.69137,7.948387,-0.136638,-403.6075,228.2431,-393.5224]
    elif 1200<=Temperature<6000:
        CO2constants=[Temperature,58.16639,2.720074,-0.492289,0.038844,-6.447293,-425.9186,263.6125,-393.5224]
    else:
        raise Exception('CO2 temp too high')
    T,A,B,C,D,E,F,G,H = CO2constants
    t = T/1000
    h = A*t + B*(t**2)/2 + C*(t**3)/3 + D*(t**4)/4 - E/t + F - H
    return h #kJ/mol

#Entropy

def Entro_Fe(Temperature):
    if Temperature <298:
        raise Exception('Fe temp too low')
    elif 298<=Temperature<700:# in range(298, 700):#298-699
        FeConstants=[Temperature,18.42868,24.64301,-8.91372,9.664706,-0.012643,-6.573022,42.51488,0]
    elif 700<=Temperature<1042:
        FeConstants=[Temperature,-57767.65,137919.7,-122773.2,38682.42,3993.08,24078.67,-87364.01,0]
    elif 1042<=Temperature<1100:
        FeConstants=[Temperature,-325.8859,28.92876,0,0,411.9629,745.8231,241.8766,0]
    elif 1100<=Temperature<1809:
        FeConstants=[Temperature,-776.7387,919.4005,-383.7184,57.08148,242.1369,697.6234,-558.3674,0]
    else:
        raise Exception('Fe temp too high')
    T,A,B,C,D,E,F,G,H = FeConstants
    t = T/1000
    s = (A*(m.log(t)) + B*t + C*(t**2)/2 + D*(t**3)/3 - E/(2*(t**2)) + G) / 1000
    return s #kJ/mol K


def Entro_FeO(Temperature):
    if Temperature <298:
        raise Exception('FeO temp too low')
    elif 298<=Temperature<1650:
        FeOconstants=[Temperature,45.7512,18.78553,-5.952201,0.852779,-0.081265,-286.7429,110.312,-272.0441]
    elif 1650<=Temperature<5000:
        FeOconstants=[Temperature,68.1992,-55.01232,0.0000000001195227,-21.64302,-40.9268,-281.4326,137.8377,-249.5321]        
    else:
        raise Exception('FeO temp too high')
    T,A,B,C,D,E,F,G,H = FeOconstants
    t = T/1000
    s = (A*(m.log(t)) + B*t + C*(t**2)/2 + D*(t**3)/3 - E/(2*(t**2)) + G) / 1000
    return s #kJ/mol K


def Entro_Fe3O4(Temperature):
    if Temperature <298:
        raise Exception('Fe3O4 temp too low')
    elif 298<=Temperature<900:
        Fe3O4constants=[Temperature,104.2096,178.5108,10.6151,1.132534,-0.994202,-1163.336,212.0585,-1120.894]
    elif 900<=Temperature<3000:
        Fe3O4constants=[Temperature,200.832,0.0000001586435,-0.00000006661682,0.000000009452452,0.0000000318602,\
                     -1174.135,388.079,-1120.894]        
    else:
        raise Exception('Fe3O4 temp too high')
    T,A,B,C,D,E,F,G,H = Fe3O4constants
    t = T/1000
    s = (A*(m.log(t)) + B*t + C*(t**2)/2 + D*(t**3)/3 - E/(2*(t**2)) + G) / 1000
    return s #kJ/mol K


def Entro_Fe2O3(Temperature):
    if Temperature <298:
        raise Exception('Fe2O3 temp too low')
    elif 298<=Temperature<950:
        Fe2O3constants=[Temperature,93.43834,108.3577,-50.86447,25.58683,-1.61133,-863.2094,161.0719,-825.5032]
    elif 950<=Temperature<1050:
        Fe2O3constants=[Temperature,150.624,0,0,0,0,-875.6066,252.8814,-825.5032]
    elif 1050<=Temperature<2500:
        Fe2O3constants=[Temperature,110.9362,32.04714,-9.192333,0.901506,5.433677,-843.1471,228.3548,-825.5032]        
    else:
        raise Exception('Fe2O3 temp too high')
    T,A,B,C,D,E,F,G,H = Fe2O3constants
    t = T/1000
    s = (A*(m.log(t)) + B*t + C*(t**2)/2 + D*(t**3)/3 - E/(2*(t**2)) + G) / 1000
    return s #kJ/mol K


def Entro_O2(Temperature):
    if Temperature <100:
        raise Exception('O2 temp too low')
    elif 100<=Temperature<700:
        O2constants=[Temperature,31.32234,-20.23531,57.86644,-36.50624,-0.007374,-8.903471,246.7945,0]
    elif 700<=Temperature<2000:
        O2constants=[Temperature,30.03235,8.772972,-3.988133,0.788313,-0.741599,-11.32468,236.1663,0]
    elif 2000<=Temperature<6000:
        O2constants=[Temperature,20.91111,10.72071,-2.020498,0.146449,9.245722,5.337651,237.6185,0]        
    else:
        raise Exception('O2 temp too high')
    T,A,B,C,D,E,F,G,H = O2constants
    t = T/1000
    s = (A*(m.log(t)) + B*t + C*(t**2)/2 + D*(t**3)/3 - E/(2*(t**2)) + G) / 1000
    return s #kJ/mol K

def Entro_N2(Temperature):
    if Temperature <100:
        raise Exception('N2 temp too low')
    elif 100<=Temperature<500:
        N2constants=[Temperature,28.98641,1.853978,-9.647459,16.63537,0.000117,-8.671914,226.4168,0]
    elif 500<=Temperature<2000:
        N2constants=[Temperature,19.50583,19.88705,-8.598535,1.369784,0.527601,-4.935202,212.39,0]
    elif 2000<=Temperature<6000:
        N2constants=[Temperature,35.51872,1.128728,-0.196103,0.014662,-4.55376,-18.97091,224.981,0]        
    else:
        raise Exception('N2 temp too high')
    T,A,B,C,D,E,F,G,H = N2constants
    t = T/1000
    s = (A*(m.log(t)) + B*t + C*(t**2)/2 + D*(t**3)/3 - E/(2*(t**2)) + G) / 1000
    return s #kJ/mol K


def Entro_H2(Temperature):
    if Temperature <298:
        raise Exception('H2 temp too low')
    elif 298<=Temperature<1000:
        H2constants=[Temperature,33.066178,-11.363417,11.432816,-2.772874,-0.158558,-9.980797,172.707974,0]
    elif 1000<=Temperature<2500:
        H2constants=[Temperature,18.563083,12.257357,-2.859786,0.268238,1.97799,-1.147438,156.288133,0]        
    elif 2500<=Temperature<6000:
        H2constants=[Temperature,43.41356,-4.293079,1.272428,-0.096876,-20.533862,-38.515158,162.081354,0]
    else:
        raise Exception('H2 temp too high')
    T,A,B,C,D,E,F,G,H = H2constants
    t = T/1000
    s = (A*(m.log(t)) + B*t + C*(t**2)/2 + D*(t**3)/3 - E/(2*(t**2)) + G) / 1000
    return s #kJ/mol K


def Entro_H2Og(Temperature):
    if Temperature <298:
        raise Exception('H2Og (steam) temp too low')
    elif 298<=Temperature<1700:
        H2OgConstants=[Temperature,30.092,6.832514,6.793435,-2.53448,0.082139,-250.881,223.3967,-241.8264]
    elif 1700<=Temperature<6000:
        H2OgConstants=[Temperature,41.96426,8.622053,-1.49978,0.098119,-11.15764,-272.1797,219.7809,-241.8264]        
    else:
        raise Exception('H2Og (stream) temp too high')
    T,A,B,C,D,E,F,G,H = H2OgConstants
    t = T/1000
    s = (A*(m.log(t)) + B*t + C*(t**2)/2 + D*(t**3)/3 - E/(2*(t**2)) + G) / 1000
    return s #kJ/mol K

def Entro_CH4(Temperature):
    if Temperature <298:
        raise Exception('CH4 temp too low')
    elif 298<=Temperature<1300:
        CH4constants=[Temperature,-0.703029,108.4773,-42.52157,5.862788,0.678565,-76.84376,158.7163,-74.8731]
    elif 1300<=Temperature<6000:
        CH4constants=[Temperature,85.81217,11.26467,-2.114146,0.13819,-26.42221,-153.5327,224.4143,-74.8731]
    else:
        raise Exception('CH4 temp too high')
    T,A,B,C,D,E,F,G,H = CH4constants
    t = T/1000
    s = (A*(m.log(t)) + B*t + C*(t**2)/2 + D*(t**3)/3 - E/(2*(t**2)) + G) / 1000
    return s #kJ/mol


def Entro_CO2(Temperature):
    if Temperature <298:
        raise Exception('CO2 temp too low')
    elif 298<=Temperature<1200:
        CO2constants=[Temperature,24.99735,55.18696,-33.69137,7.948387,-0.136638,-403.6075,228.2431,-393.5224]
    elif 1200<=Temperature<6000:
        CO2constants=[Temperature,58.16639,2.720074,-0.492289,0.038844,-6.447293,-425.9186,263.6125,-393.5224]
    else:
        raise Exception('CO2 temp too high')
    T,A,B,C,D,E,F,G,H = CO2constants
    t = T/1000
    s = (A*(m.log(t)) + B*t + C*(t**2)/2 + D*(t**3)/3 - E/(2*(t**2)) + G) / 1000
    return s #kJ/mol