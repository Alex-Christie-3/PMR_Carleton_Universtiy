#GUI Experimentation

import tkinter as t
import Iron_Combustion_v3 as c

#make GUI window
window=t.Tk()

#window title
window.title("Iron Combustion Calculator")

#window size
window.geometry('500x500')

#input label
input_label=t.Label(window,text='INPUTS')
input_label.grid(row=0,column=0)

#input 2
label_2=t.Label(window,text='Desired Power [kW]')
label_2.grid(row=2,column=0)
input_2=t.Entry(window,width=10)
input_2.grid(row=2,column=1)
input_2.insert(0,'20')

#input 3
label_3=t.Label(window,text='Desired Flame Temp [K]')
label_3.grid(row=3,column=0)
input_3=t.Entry(window,width=10)
input_3.grid(row=3,column=1)
input_3.insert(0,'1750')

#input 4
label_4=t.Label(window,text='Combustion Efficiency')
label_4.grid(row=4,column=0)
input_4=t.Entry(window,width=10)
input_4.grid(row=4,column=1)
input_4.insert(0,'1')

#input 5
label_5=t.Label(window,text='Mass Fraction - FeO')
label_5.grid(row=5,column=0)
input_5=t.Entry(window,width=10)
input_5.grid(row=5,column=1)
input_5.insert(0,'0')

#input 6
label_6=t.Label(window,text='Mass Fraction - Fe3O4')
label_6.grid(row=6,column=0)
input_6=t.Entry(window,width=10)
input_6.grid(row=6,column=1)
input_6.insert(0,'1')

#input 7
label_7=t.Label(window,text='Mass Fraction - Fe2O3')
label_7.grid(row=7,column=0)
input_7=t.Entry(window,width=10)
input_7.grid(row=7,column=1)
input_7.insert(0,'0')

#input 8
label_8=t.Label(window,text='Temperature In [deg C]')
label_8.grid(row=8,column=0)
input_8=t.Entry(window,width=10)
input_8.grid(row=8,column=1)
input_8.insert(0,'30')

#space 1
space_1=t.Label(window,text='')
space_1.grid(row=9,column=0)

#output label
output_label=t.Label(window,text='OUTPUT')
output_label.grid(row=10,column=0)

def Calculate_Callback():
    
    in_2=input_2.get()
    in_3=input_3.get()
    in_4=input_4.get()
    in_5=input_5.get()
    in_6=input_6.get()
    in_7=input_7.get()
    in_8=input_8.get()
    
    power_target=float(in_2)
    flame_temp_target=float(in_3)
    combustion_efficiency=float(in_4)
    mass_fraction_FeO=float(in_5)
    mass_fraction_Fe3O4=float(in_6)
    mass_fraction_Fe2O3=float(in_7)
    T_in_degC=float(in_8)
    
    results=c.GUI_In_Out(power_target,flame_temp_target,mass_fraction_FeO,mass_fraction_Fe3O4,\
               mass_fraction_Fe2O3,combustion_efficiency,T_in_degC)
    
    #output 1
    label_out_1=t.Label(window,text='Iron Powder Flow [g/s]')
    label_out_1.grid(row=11,column=0)
    out_1=str(round(results['Fe_in'],4))
    output_1=t.Label(window,text=out_1)
    output_1.grid(row=11,column=1)

    #output 2
    label_out_2=t.Label(window,text='Equivalence Ratio')
    label_out_2.grid(row=12,column=0)    
    out_2=str(round(results['phi'],4))
    output_2=t.Label(window,text=out_2)
    output_2.grid(row=12,column=1)

    #output 3
    label_out_3=t.Label(window,text='Air Flow In [g/s]')
    label_out_3.grid(row=13,column=0)
    out_3=str(round(results['air_flow'],4))
    output_3=t.Label(window,text=out_3)
    output_3.grid(row=13,column=1)
    
    #output 4
    label_out_4=t.Label(window,text='O2_Concentration')
    label_out_4.grid(row=14,column=0)
    out_4=str(round(results['O2_concentration'],4))
    output_4=t.Label(window,text=out_4)
    output_4.grid(row=14,column=1)    
    
    return

calculate_button=t.Button(window,text='Calculate',command=Calculate_Callback)
calculate_button.grid(row=0,column=2)


window.mainloop()

#t.Tk(screenName=None, baseName=None, className='Tk', useTk=True, sync=False, use=None)