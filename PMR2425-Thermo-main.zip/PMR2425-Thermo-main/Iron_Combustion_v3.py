import cantera as ct
import IronOxideNISTpoly_v3 as p

#CONSTANTS

#Air composition
O2_content=0.209476
H2O_content=0.02
other_content=0.009684
N2_content=1-O2_content-H2O_content-other_content


#Molar masses (kg/mol)
M_Fe=55.845/1000
M_O=15.999/1000
M_N=14.007/1000
M_H=1.008/1000
M_air=28.9647/1000
M_O2=2*M_O
M_N2=2*M_O
M_FeO=M_Fe+M_O
M_Fe3O4=(3*M_Fe)+(4*M_O)
M_Fe2O3=(2*M_Fe)+(3*M_O)
M_H2O=(2*M_H)+M_O


#Enthalpies of formation for iron oxides (kJ/mol)
hf_FeO=-266.5
hf_Fe3O4=-1120.89
hf_Fe2O3=-825.5

def Powder_Flow(power_target,mass_fraction_FeO,mass_fraction_Fe3O4,\
               mass_fraction_Fe2O3,combustion_efficiency): #kW, g/s
    
    mass_fraction_sum=mass_fraction_FeO+mass_fraction_Fe3O4+mass_fraction_Fe2O3
    if mass_fraction_sum!=1:
        print('WARNING: SUM OF MASS FRACTION INPUTS NOT EQUAL TO 1')    
    
    den=(mass_fraction_FeO/M_FeO)+(mass_fraction_Fe3O4/M_Fe3O4)+(mass_fraction_Fe2O3/M_Fe2O3)
    
    mol_fraction_FeO=(mass_fraction_FeO/M_FeO)/den
    mol_fraction_Fe3O4=(mass_fraction_Fe3O4/M_Fe3O4)/den
    mol_fraction_Fe2O3=(mass_fraction_Fe2O3/M_Fe2O3)/den
    
    oxides_out=-power_target/((hf_FeO*mol_fraction_FeO)+(hf_Fe3O4*mol_fraction_Fe3O4)+(hf_Fe2O3*mol_fraction_Fe2O3)) #kW
    
    Fe_in_mol=(oxides_out*(mol_fraction_FeO+(3*mol_fraction_Fe3O4)+(2*mol_fraction_Fe2O3)))/combustion_efficiency
    
    Fe_in_mass=Fe_in_mol*M_Fe*1000 #g/s
    
    return Fe_in_mass



def EquivalenceRatio(flame_temp_target,mass_fraction_FeO,mass_fraction_Fe3O4,\
                     mass_fraction_Fe2O3,combustion_efficiency,T_in): #K
    
    #Check for valid inputs
    
    mass_fraction_sum=mass_fraction_FeO+mass_fraction_Fe3O4+mass_fraction_Fe2O3
    if mass_fraction_sum!=1:
        print('WARNING: SUM OF MASS FRACTION INPUTS NOT EQUAL TO 1')
    
    #ADDITIONAL CONSTANTS DEFINITIONS
    
    T_ref=298 #K
    T_powder_in=T_in #K
    T_air_in=T_in #K
    T_out_target=flame_temp_target #K
    
    #STOICHIOMETRIC CALCULATIONS

    Fe_in_mol=1
    
    den=(mass_fraction_FeO/M_FeO)+(mass_fraction_Fe3O4/M_Fe3O4)+(mass_fraction_Fe2O3/M_Fe2O3)
    
    mol_fraction_FeO=(mass_fraction_FeO/M_FeO)/den
    mol_fraction_Fe3O4=(mass_fraction_Fe3O4/M_Fe3O4)/den
    mol_fraction_Fe2O3=(mass_fraction_Fe2O3/M_Fe2O3)/den
    
    Fe_out_mol=Fe_in_mol*(1-combustion_efficiency) #mol/s
    
    oxides_out=(Fe_in_mol-Fe_out_mol)/(mol_fraction_FeO+(3*mol_fraction_Fe3O4)+(2*mol_fraction_Fe2O3)) #mol/s
    
    FeO_out=oxides_out*mol_fraction_FeO #mol/s
    Fe3O4_out=oxides_out*mol_fraction_Fe3O4 #mol/s
    Fe2O3_out=oxides_out*mol_fraction_Fe2O3 #mol/s
    
    air_stoich=(FeO_out+(4*Fe3O4_out)+(3*Fe2O3_out))/(2*O2_content) #mol/s
    
    T_out=T_air_in
    gap=5 #just to active while loop
    inc=0.00005 #Can be editted, decrease will make solution more accurate but will take longer
    phi=2
    counter_1=0
    
    while gap>0.0001:
        if counter_1==0:
            gap=0
        
        phi=phi+inc*gap
        
        if (counter_1==1) and (gap<0):
            raise Exception('Desired flame temp too high')        
        
        air=phi*air_stoich #mol/s
        
        O2_in=air*O2_content
        N2_in=air*N2_content
        
        O2_out=((2*air*O2_content)-FeO_out-(4*Fe3O4_out)-(3*Fe2O3_out))/2 #mol/s
        N2_out=air*N2_content
        
        
        #Determining Known Ethalpies
        #IN
        
        h_Fe_in=p.Enth_Fe(T_powder_in)
        h_N2_in=p.Enth_N2(T_air_in)
        h_O2_in=p.Enth_O2(T_air_in)
        
        #REF
        
        h_Fe_ref=p.Enth_Fe(T_ref)
        h_FeO_ref=p.Enth_FeO(T_ref)
        h_Fe3O4_ref=p.Enth_Fe3O4(T_ref)
        h_Fe2O3_ref=p.Enth_Fe2O3(T_ref)
        h_N2_ref=p.Enth_N2(T_ref)
        h_O2_ref=p.Enth_O2(T_ref)
        
        
        #Adiabatic Flame Temp Calculations

        left=(Fe_in_mol*h_Fe_in)-(Fe_in_mol*h_Fe_ref)\
            +(O2_in*h_O2_in)-(O2_in*h_O2_ref)+(N2_in*h_N2_in)-(N2_in*h_N2_ref)\
            +(FeO_out*h_FeO_ref)+(Fe3O4_out*h_Fe3O4_ref)+(Fe2O3_out*h_Fe2O3_ref)\
            -(FeO_out*hf_FeO)-(Fe3O4_out*hf_Fe3O4)-(Fe2O3_out*hf_Fe2O3)\
            +(Fe_out_mol*h_Fe_ref)+(O2_out*h_O2_ref)+(N2_out*h_N2_ref)
        
        
        
        #Initial Guess for Adiabatic Flame Temperature
        
        T_out=T_air_in
        
        
        #Initial Guess for Unknown Enthalpies
        
        h_Fe_out=p.Enth_Fe(T_out)
        h_FeO_out=p.Enth_FeO(T_out)
        h_Fe3O4_out=p.Enth_Fe3O4(T_out)
        h_Fe2O3_out=p.Enth_Fe2O3(T_out)
        
        h_O2_out=p.Enth_O2(T_out)
        h_N2_out=p.Enth_N2(T_out)
        
        right=(Fe_out_mol*h_Fe_out)\
            +(FeO_out*h_FeO_out)+(Fe3O4_out*h_Fe3O4_out)+(Fe2O3_out*h_Fe2O3_out)\
            +(O2_out*h_O2_out)+(N2_out*h_N2_out)
        
        #Iterating to Adiabatic Flame Temperature
        
        diff=left-right
        counter_2=0
        eta=0.5 
        T_out=T_out+eta*diff
        
        while diff>0.0001:
            T_out=T_out+eta*diff
            
            h_Fe_out=p.Enth_Fe(T_out)
            h_FeO_out=p.Enth_FeO(T_out)
            h_Fe3O4_out=p.Enth_Fe3O4(T_out)
            h_Fe2O3_out=p.Enth_Fe2O3(T_out)
            
            h_O2_out=p.Enth_O2(T_out)
            h_N2_out=p.Enth_N2(T_out)
            
            right=(Fe_out_mol*h_Fe_out)\
                +(FeO_out*h_FeO_out)+(Fe3O4_out*h_Fe3O4_out)+(Fe2O3_out*h_Fe2O3_out)\
                +(O2_out*h_O2_out)+(N2_out*h_N2_out)
            
            diff=left-right
        
        gap=T_out-T_out_target
        counter_1+=1
    
    #print('Flame Temp',T_out)
        
    return phi    




def Air_Flow(Fe_in,phi,mass_fraction_FeO,mass_fraction_Fe3O4,\
             mass_fraction_Fe2O3,combustion_efficiency): #g/s of Fe_in, g/s air in as function output
    
    #Check for valid inputs
    
    mass_fraction_sum=mass_fraction_FeO+mass_fraction_Fe3O4+mass_fraction_Fe2O3
    if mass_fraction_sum!=1:
        print('WARNING: MASS FRACTION INPUT NOT EQUAL TO 1')
    
    #STOICHIOMETRIC CALCULATIONS

    Fe_in_mol=Fe_in/(1000*M_Fe) #mol/s
    
    den=(mass_fraction_FeO/M_FeO)+(mass_fraction_Fe3O4/M_Fe3O4)+(mass_fraction_Fe2O3/M_Fe2O3)
    
    mol_fraction_FeO=(mass_fraction_FeO/M_FeO)/den
    mol_fraction_Fe3O4=(mass_fraction_Fe3O4/M_Fe3O4)/den
    mol_fraction_Fe2O3=(mass_fraction_Fe2O3/M_Fe2O3)/den
    
    Fe_out_mol=Fe_in_mol*(1-combustion_efficiency) #mol/s
    
    oxides_out=(Fe_in_mol-Fe_out_mol)/(mol_fraction_FeO+(3*mol_fraction_Fe3O4)+(2*mol_fraction_Fe2O3)) #mol/s
    
    FeO_out=oxides_out*mol_fraction_FeO #mol/s
    Fe3O4_out=oxides_out*mol_fraction_Fe3O4 #mol/s
    Fe2O3_out=oxides_out*mol_fraction_Fe2O3 #mol/s
    
    air_stoich=(FeO_out+(4*Fe3O4_out)+(3*Fe2O3_out))/(2*O2_content) #mol/s
    
    air=phi*air_stoich #mol/s
    
    O2_in=air*O2_content
    N2_in=air*N2_content
    
    O2_out=((2*air*O2_content)-FeO_out-(4*Fe3O4_out)-(3*Fe2O3_out))/2 #mol/s
    N2_out=air*N2_content    
    
    m_dot_air=air*M_air*1000 #g/s
    
    return m_dot_air


def O2_Conc(Fe_in,phi,mass_fraction_FeO,mass_fraction_Fe3O4,\
             mass_fraction_Fe2O3,combustion_efficiency): #g/s of Fe_in, g/s air in as function output
    
    #Check for valid inputs
    
    mass_fraction_sum=mass_fraction_FeO+mass_fraction_Fe3O4+mass_fraction_Fe2O3
    if mass_fraction_sum!=1:
        print('WARNING: MASS FRACTION INPUT NOT EQUAL TO 1')
    
    #STOICHIOMETRIC CALCULATIONS

    Fe_in_mol=Fe_in/(1000*M_Fe) #mol/s
    
    den=(mass_fraction_FeO/M_FeO)+(mass_fraction_Fe3O4/M_Fe3O4)+(mass_fraction_Fe2O3/M_Fe2O3)
    
    mol_fraction_FeO=(mass_fraction_FeO/M_FeO)/den
    mol_fraction_Fe3O4=(mass_fraction_Fe3O4/M_Fe3O4)/den
    mol_fraction_Fe2O3=(mass_fraction_Fe2O3/M_Fe2O3)/den
    
    Fe_out_mol=Fe_in_mol*(1-combustion_efficiency) #mol/s
    
    oxides_out=(Fe_in_mol-Fe_out_mol)/(mol_fraction_FeO+(3*mol_fraction_Fe3O4)+(2*mol_fraction_Fe2O3)) #mol/s
    
    FeO_out=oxides_out*mol_fraction_FeO #mol/s
    Fe3O4_out=oxides_out*mol_fraction_Fe3O4 #mol/s
    Fe2O3_out=oxides_out*mol_fraction_Fe2O3 #mol/s
    
    air_stoich=(FeO_out+(4*Fe3O4_out)+(3*Fe2O3_out))/(2*O2_content) #mol/s
    
    air=phi*air_stoich #mol/s
    
    O2_in=air*O2_content
    N2_in=air*N2_content
    
    O2_out=((2*air*O2_content)-FeO_out-(4*Fe3O4_out)-(3*Fe2O3_out))/2 #mol/s
    N2_out=air*N2_content    
    
    O2_concentration=O2_out/(O2_out+N2_out)
    
    return O2_concentration



def GUI_In_Out(power_target,flame_temp_target,mass_fraction_FeO,mass_fraction_Fe3O4,\
               mass_fraction_Fe2O3,combustion_efficiency,T_in_degC):
    
    T_in=T_in_degC+273.15
    
    Fe_in=Powder_Flow(power_target,mass_fraction_FeO,mass_fraction_Fe3O4,\
               mass_fraction_Fe2O3,combustion_efficiency)

    phi=EquivalenceRatio(flame_temp_target,mass_fraction_FeO,mass_fraction_Fe3O4,\
                         mass_fraction_Fe2O3,combustion_efficiency,T_in)
    
    air_flow=Air_Flow(Fe_in,phi,mass_fraction_FeO,mass_fraction_Fe3O4,\
                mass_fraction_Fe2O3,combustion_efficiency)
    
    O2_concentration=O2_Conc(Fe_in,phi,mass_fraction_FeO,mass_fraction_Fe3O4,\
             mass_fraction_Fe2O3,combustion_efficiency)
    
    results={'Fe_in':Fe_in,'phi':phi,'air_flow':air_flow,\
             'O2_concentration':O2_concentration}
    
    return results