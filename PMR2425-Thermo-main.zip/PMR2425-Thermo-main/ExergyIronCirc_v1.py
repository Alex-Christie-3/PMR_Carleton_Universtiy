import Combustion_v1 as q
import NISTpoly_v2_H2Omod as r
import matplotlib.pyplot as plt

#Chemical Exergies (kJ/mol)
ex_ch_Fe=374.3
ex_ch_FeO=124.9#111.3
ex_ch_Fe3O4=116.3
ex_ch_Fe2O3=12.4
ex_ch_O2=3.97
ex_ch_N2=0.69
ex_ch_H2=236.09
ex_ch_H2OL=0.9
ex_ch_H2Og=9.5
ex_ch_C=409.87
ex_ch_CO2=19.48
ex_ch_NH3=337.9
ex_ch_CH4=831.2
ex_ch_C12H23=6000#'blah' #*********************FIX*********************

#Enthalpies of Formation (kJ/mol)
hf_H2OL=-285.83
hf_Fe3O4=-1120.89
hf_H2Og=-241.82

def Ex_Iron(phi,T_dead):
    
    T_ref=T_dead
    a=q.Iron_Comb_Fe3O4(phi,T_ref)
    T_out=a['T_flame']
    Fe_in=a['Fe_in']
    O2_in=a['O2_in']
    N2_in=a['N2_in']
    Fe3O4_out=a['Fe3O4_out']
    O2_out=a['O2_out']
    N2_out=a['N2_out']
    
    #Enthalpy and Entropy Out
    h_Fe3O4_out=r.Enth_Fe3O4(T_out)
    h_N2_out=r.Enth_N2(T_out)
    h_O2_out=r.Enth_O2(T_out)
    
    s_Fe3O4_out=r.Entro_Fe3O4(T_out)
    s_N2_out=r.Entro_N2(T_out)
    s_O2_out=r.Entro_O2(T_out)    
    
    
    #Enthalpy and Entropy Ref
    h_Fe3O4_ref=r.Enth_Fe3O4(T_ref)
    h_N2_ref=r.Enth_N2(T_ref)
    h_O2_ref=r.Enth_O2(T_ref)
    
    s_Fe3O4_ref=r.Entro_Fe3O4(T_ref)
    s_N2_ref=r.Entro_N2(T_ref)
    s_O2_ref=r.Entro_O2(T_ref)
    
    #Physcial Exergy Out
    ex_ph_Fe3O4=(h_Fe3O4_out-h_Fe3O4_ref)-T_dead*(s_Fe3O4_out-s_Fe3O4_ref)
    ex_ph_N2=(h_N2_out-h_N2_ref)-T_dead*(s_N2_out-s_N2_ref)
    ex_ph_O2=(h_O2_out-h_O2_ref)-T_dead*(s_O2_out-s_O2_ref)
    
    #Thermal Exergy w stoichiometric coefficients
    ex_th_Fe_in=Fe_in*ex_ch_Fe
    ex_th_O2_in=O2_in*ex_ch_O2
    ex_th_N2_in=N2_in*ex_ch_N2
    
    ex_th_Fe3O4=Fe3O4_out*(ex_ch_Fe3O4+ex_ph_Fe3O4)
    ex_th_O2_out=O2_out*(ex_ch_O2+ex_ph_O2)
    ex_th_N2_out=N2_out*(ex_ch_N2+ex_ph_N2)
    
    Ex_in=ex_th_Fe_in+ex_th_O2_in+ex_th_N2_in
    Ex_out=ex_th_Fe3O4+ex_th_O2_out+ex_th_N2_out
    
    Ex_des=Ex_in-Ex_out
    
    #n_ex_iron=1-(Ex_des/Ex_in)
    n_ex_comb=1-(Ex_des/Ex_in)
    n_ex_carnot=1-(283.15/T_out)
    
    n_ex_iron=n_ex_comb*n_ex_carnot
    
    return n_ex_iron


#Electrolysis

def Ex_Elec():
    
    #Stoichiometric Coefficients
    H2O_in=2
    Electricity_in=2
    H2_out=2
    O2_out=1
    
    #Chemical Exergy of Electricity
    
    ex_ch_Electricity=-hf_H2OL #kJ/mol per mol of H2 produced
    
    Ex_in=(H2O_in*ex_ch_H2OL)+(Electricity_in*ex_ch_Electricity)
    print(Ex_in)
    Ex_out=(H2_out*ex_ch_H2)+(O2_out*ex_ch_O2)
    print(Ex_out)
    
    Ex_des=Ex_in-Ex_out
    
    n_ex_elec=1-(Ex_des/Ex_in)
    
    return n_ex_elec


#Reduction

def Ex_Red(T_red,T_dead):
    
    H2_in=4
    Fe3O4_in=1
    Fe_out=3
    H2O_out=4
    
    h_Fe3O4_hot=r.Enth_Fe3O4(T_red)
    h_Fe3O4_ref=r.Enth_Fe3O4(T_dead)
    h_H2_hot=r.Enth_H2(T_red)
    h_H2_ref=r.Enth_H2(T_dead)
    
    E_TempRise=(h_Fe3O4_hot-h_Fe3O4_ref)+4*(h_H2_hot-h_H2_ref)
    E_endothermic=-(hf_Fe3O4-4*hf_H2Og) #returns heat required
    
    Ex_in=(H2_in*ex_ch_H2)+(Fe3O4_in*ex_ch_Fe3O4)
    Ex_out=(Fe_out*ex_ch_Fe)+(H2O_out*ex_ch_H2Og)
    
    Ex_des=Ex_in-Ex_out
    
    n_ex_red=(Ex_in-Ex_des)/(Ex_in+E_TempRise+E_endothermic)
    
    return n_ex_red



#Overall


def Ex_Overall_Circ(phi,T_dead,T_red):
    
    n_iron=Ex_Iron(phi,T_dead)
    n_elec=Ex_Elec()
    n_red=Ex_Red(T_red,T_dead)
    
    n_overall=n_iron*n_elec*n_red
    
    return n_overall


n=Ex_Overall_Circ(3.432872481,300,1173.15)
print(n)


def Ex_Graph_Both(phi_low,phi_high,T_dead):
    
    phi_low=int(phi_low*100)
    phi_high=int(phi_high*100)
    
    comb_temp=[]
    ex_co=[]
    ex_circ=[]
    
    for i in range(phi_low,phi_high,5):
        phi=i/100
        print(phi)
        a=q.Iron_Comb_Fe3O4(phi,T_dead)
        T_flame=a['T_flame']        
        n_co=Ex_Iron(phi,T_dead)
        n_circ=Ex_Overall_Circ(phi,T_dead,1173.15)
        comb_temp.append(T_flame)
        ex_co.append(100*n_co)
        ex_circ.append(100*n_circ)
    
    plt.plot(comb_temp,ex_co, label='cogen')
    plt.plot(comb_temp,ex_circ, label='circular')
    plt.title('Exergy Efficiency')
    plt.xlabel('Adiabatic Flame Temp [K]')
    plt.ylabel('Overall Exergy Efficency [%]')
    plt.grid(color='gray', linestyle='--', linewidth=0.5)
    plt.figsize=(5, 10)
    plt.legend()
    plt.show()
    
    return 'Graph Displayed'

Ex_Graph_Both(2.1,5,300)