import Combustion_v1 as q
import NISTpoly_v2_H2Omod as r

#Chemical Exergies (kJ/mol)
ex_ch_Fe=374.3
ex_ch_FeO=124.9#111.3
ex_ch_Fe3O4=116.3
ex_ch_Fe2O3=12.4
ex_ch_O2=3.97
ex_ch_N2=0.69
ex_ch_H2=236.09
ex_ch_H2OL=0.9
ex_ch_H2Og=9.5
ex_ch_C=409.87
ex_ch_CO2=19.48
ex_ch_NH3=337.9
ex_ch_CH4=831.2
ex_ch_C12H23=6000#'blah' #*********************FIX*********************



def Ex_Iron(phi,T_dead):
    
    T_ref=T_dead
    a=q.Iron_Comb_Fe3O4(phi,T_ref)
    T_out=a['T_flame']
    Fe_in=a['Fe_in']
    O2_in=a['O2_in']
    N2_in=a['N2_in']
    Fe3O4_out=a['Fe3O4_out']
    O2_out=a['O2_out']
    N2_out=a['N2_out']
    
    #Enthalpy and Entropy Out
    h_Fe3O4_out=r.Enth_Fe3O4(T_out)
    h_N2_out=r.Enth_N2(T_out)
    h_O2_out=r.Enth_O2(T_out)
    
    s_Fe3O4_out=r.Entro_Fe3O4(T_out)
    s_N2_out=r.Entro_N2(T_out)
    s_O2_out=r.Entro_O2(T_out)    
    
    
    #Enthalpy and Entropy Ref
    h_Fe3O4_ref=r.Enth_Fe3O4(T_ref)
    h_N2_ref=r.Enth_N2(T_ref)
    h_O2_ref=r.Enth_O2(T_ref)
    
    s_Fe3O4_ref=r.Entro_Fe3O4(T_ref)
    s_N2_ref=r.Entro_N2(T_ref)
    s_O2_ref=r.Entro_O2(T_ref)
    
    #Physcial Exergy Out
    ex_ph_Fe3O4=(h_Fe3O4_out-h_Fe3O4_ref)-T_dead*(s_Fe3O4_out-s_Fe3O4_ref)
    ex_ph_N2=(h_N2_out-h_N2_ref)-T_dead*(s_N2_out-s_N2_ref)
    ex_ph_O2=(h_O2_out-h_O2_ref)-T_dead*(s_O2_out-s_O2_ref)
    
    #Thermal Exergy w stoichiometric coefficients
    ex_th_Fe_in=Fe_in*ex_ch_Fe
    ex_th_O2_in=O2_in*ex_ch_O2
    ex_th_N2_in=N2_in*ex_ch_N2
    
    ex_th_Fe3O4=Fe3O4_out*(ex_ch_Fe3O4+ex_ph_Fe3O4)
    ex_th_O2_out=O2_out*(ex_ch_O2+ex_ph_O2)
    ex_th_N2_out=N2_out*(ex_ch_N2+ex_ph_N2)
    
    Ex_in=ex_th_Fe_in+ex_th_O2_in+ex_th_N2_in
    Ex_out=ex_th_Fe3O4+ex_th_O2_out+ex_th_N2_out
    
    Ex_des=Ex_in-Ex_out
    
    #n_ex_iron=1-(Ex_des/Ex_in)
    n_ex_comb=1-(Ex_des/Ex_in)
    n_ex_carnot=1-(283.15/T_out)
    
    n_ex_iron=n_ex_comb*n_ex_carnot
    
    return n_ex_iron


def Ex_Diesel(phi,T_dead):
    
    T_ref=T_dead
    b=q.Diesel_Comb(phi,T_ref)
    
    T_out=b['T_flame']
    C12H23_in=b['C12H23_in']
    O2_in=b['O2_in']
    N2_in=b['N2_in']
    CO2_out=b['CO2_out']
    H2O_out=b['H2O_out']
    O2_out=b['O2_out']
    N2_out=b['N2_out']
    
    #Enthalpy and Entropy Out
    h_CO2_out=r.Enth_CO2(T_out)
    h_H2O_out=r.Enth_H2Og(T_out)
    h_N2_out=r.Enth_N2(T_out)
    h_O2_out=r.Enth_O2(T_out)
    
    s_CO2_out=r.Entro_CO2(T_out)
    s_H2O_out=r.Entro_H2Og(T_out)
    s_N2_out=r.Entro_N2(T_out)
    s_O2_out=r.Entro_O2(T_out)    
    
    
    #Enthalpy and Entropy Ref
    h_CO2_ref=r.Enth_CO2(T_ref)
    h_H2O_ref=r.Enth_H2Og(T_ref)
    h_N2_ref=r.Enth_N2(T_ref)
    h_O2_ref=r.Enth_O2(T_ref)
    
    s_CO2_ref=r.Entro_CO2(T_ref)
    s_H2O_ref=r.Entro_H2Og(T_ref)
    s_N2_ref=r.Entro_N2(T_ref)
    s_O2_ref=r.Entro_O2(T_ref)
    
    #Physcial Exergy Out
    ex_ph_CO2=(h_CO2_out-h_CO2_ref)-T_dead*(s_CO2_out-s_CO2_ref)
    ex_ph_H2O=(h_H2O_out-h_H2O_ref)-T_dead*(s_H2O_out-s_H2O_ref)
    ex_ph_N2=(h_N2_out-h_N2_ref)-T_dead*(s_N2_out-s_N2_ref)
    ex_ph_O2=(h_O2_out-h_O2_ref)-T_dead*(s_O2_out-s_O2_ref)
    
    #Thermal Exergy w stoichiometric coefficients
    ex_th_C12H23_in=C12H23_in*ex_ch_C12H23
    ex_th_O2_in=O2_in*ex_ch_O2
    ex_th_N2_in=N2_in*ex_ch_N2
    
    ex_th_CO2=CO2_out*(ex_ch_CO2+ex_ph_CO2)
    ex_th_H2O=H2O_out*(ex_ch_H2Og+ex_ph_H2O)
    ex_th_O2_out=O2_out*(ex_ch_O2+ex_ph_O2)
    ex_th_N2_out=N2_out*(ex_ch_N2+ex_ph_N2)
    
    Ex_in=ex_th_C12H23_in+ex_th_O2_in+ex_th_N2_in
    Ex_out=ex_th_CO2+ex_th_H2O+ex_th_O2_out+ex_th_N2_out
    
    Ex_des=Ex_in-Ex_out
    
    #n_ex_diesel=1-(Ex_des/Ex_in)
    n_ex_comb=1-(Ex_des/Ex_in)
    n_ex_carnot=1-(283.15/T_out)
    
    n_ex_diesel=n_ex_comb*n_ex_carnot     
    
    return n_ex_diesel


def Ex_Coal(phi,T_dead):
    
    T_ref=T_dead
    c=q.Coal_Comb(phi,T_ref)
    
    T_out=c['T_flame']
    C_in=c['C_in']
    O2_in=c['O2_in']
    N2_in=c['N2_in']
    CO2_out=c['CO2_out']
    O2_out=c['O2_out']
    N2_out=c['N2_out']

    
    #Enthalpy and Entropy Out
    h_CO2_out=r.Enth_CO2(T_out)
    h_N2_out=r.Enth_N2(T_out)
    h_O2_out=r.Enth_O2(T_out)
    
    s_CO2_out=r.Entro_CO2(T_out)
    s_N2_out=r.Entro_N2(T_out)
    s_O2_out=r.Entro_O2(T_out)    
    
    
    #Enthalpy and Entropy Ref
    h_CO2_ref=r.Enth_CO2(T_ref)
    h_N2_ref=r.Enth_N2(T_ref)
    h_O2_ref=r.Enth_O2(T_ref)
    
    s_CO2_ref=r.Entro_CO2(T_ref)
    s_N2_ref=r.Entro_N2(T_ref)
    s_O2_ref=r.Entro_O2(T_ref)
    
    #Physcial Exergy Out
    ex_ph_CO2=(h_CO2_out-h_CO2_ref)-T_dead*(s_CO2_out-s_CO2_ref)
    ex_ph_N2=(h_N2_out-h_N2_ref)-T_dead*(s_N2_out-s_N2_ref)
    ex_ph_O2=(h_O2_out-h_O2_ref)-T_dead*(s_O2_out-s_O2_ref)
    
    #Thermal Exergy w stoichiometric coefficients
    ex_th_C_in=C_in*ex_ch_C
    ex_th_O2_in=O2_in*ex_ch_O2
    ex_th_N2_in=N2_in*ex_ch_N2
    
    ex_th_CO2=CO2_out*(ex_ch_CO2+ex_ph_CO2)
    ex_th_O2_out=O2_out*(ex_ch_O2+ex_ph_O2)
    ex_th_N2_out=N2_out*(ex_ch_N2+ex_ph_N2)
    
    Ex_in=ex_th_C_in+ex_th_O2_in+ex_th_N2_in
    Ex_out=ex_th_CO2+ex_th_O2_out+ex_th_N2_out
    
    Ex_des=Ex_in-Ex_out
    
    #n_ex_coal=1-(Ex_des/Ex_in)
    n_ex_comb=1-(Ex_des/Ex_in)
    n_ex_carnot=1-(283.15/T_out)
    
    n_ex_coal=n_ex_comb*n_ex_carnot 
    
    return n_ex_coal


def Ex_Hydrogen(phi,T_dead):
    
    T_ref=T_dead
    d=q.Hydrogen_Comb(phi,T_ref)
    
    T_out=d['T_flame']
    H2_in=d['H2_in']
    O2_in=d['O2_in']
    N2_in=d['N2_in']
    H2O_out=d['H2O_out']
    O2_out=d['O2_out']
    N2_out=d['N2_out']

    
    #Enthalpy and Entropy Out
    h_H2O_out=r.Enth_H2Og(T_out)
    h_N2_out=r.Enth_N2(T_out)
    h_O2_out=r.Enth_O2(T_out)
    
    s_H2O_out=r.Entro_H2Og(T_out)
    s_N2_out=r.Entro_N2(T_out)
    s_O2_out=r.Entro_O2(T_out)    
    
    
    #Enthalpy and Entropy Ref
    h_H2O_ref=r.Enth_H2Og(T_ref)
    h_N2_ref=r.Enth_N2(T_ref)
    h_O2_ref=r.Enth_O2(T_ref)
    
    s_H2O_ref=r.Entro_H2Og(T_ref)
    s_N2_ref=r.Entro_N2(T_ref)
    s_O2_ref=r.Entro_O2(T_ref)
    
    #Physcial Exergy Out
    ex_ph_H2O=(h_H2O_out-h_H2O_ref)-T_dead*(s_H2O_out-s_H2O_ref)
    ex_ph_N2=(h_N2_out-h_N2_ref)-T_dead*(s_N2_out-s_N2_ref)
    ex_ph_O2=(h_O2_out-h_O2_ref)-T_dead*(s_O2_out-s_O2_ref)
    
    #Thermal Exergy w stoichiometric coefficients
    ex_th_H2_in=H2_in*ex_ch_H2
    ex_th_O2_in=O2_in*ex_ch_O2
    ex_th_N2_in=N2_in*ex_ch_N2
    
    ex_th_H2O=H2O_out*(ex_ch_H2Og+ex_ph_H2O)
    ex_th_O2_out=O2_out*(ex_ch_O2+ex_ph_O2)
    ex_th_N2_out=N2_out*(ex_ch_N2+ex_ph_N2)
    
    Ex_in=ex_th_H2_in+ex_th_O2_in+ex_th_N2_in
    Ex_out=ex_th_H2O+ex_th_O2_out+ex_th_N2_out
    
    Ex_des=Ex_in-Ex_out
    
    #n_ex_hydrogen=1-(Ex_des/Ex_in)
    n_ex_comb=1-(Ex_des/Ex_in)
    n_ex_carnot=1-(283.15/T_out)
    
    n_ex_hydrogen=n_ex_comb*n_ex_carnot    
    
    return n_ex_hydrogen

def Ex_Ammonia(phi,T_dead):
    
    T_ref=T_dead
    e=q.Ammonia_Comb(phi,T_ref)
    
    T_out=e['T_flame']
    NH3_in=e['NH3_in']
    O2_in=e['O2_in']
    N2_in=e['N2_in']
    H2O_out=e['H2O_out']
    O2_out=e['O2_out']
    N2_out=e['N2_out']


    
    #Enthalpy and Entropy Out
    h_H2O_out=r.Enth_H2Og(T_out)
    h_N2_out=r.Enth_N2(T_out)
    h_O2_out=r.Enth_O2(T_out)
    
    s_H2O_out=r.Entro_H2Og(T_out)
    s_N2_out=r.Entro_N2(T_out)
    s_O2_out=r.Entro_O2(T_out)    
    
    
    #Enthalpy and Entropy Ref
    h_H2O_ref=r.Enth_H2Og(T_ref)
    h_N2_ref=r.Enth_N2(T_ref)
    h_O2_ref=r.Enth_O2(T_ref)
    
    s_H2O_ref=r.Entro_H2Og(T_ref)
    s_N2_ref=r.Entro_N2(T_ref)
    s_O2_ref=r.Entro_O2(T_ref)
    
    #Physcial Exergy Out
    ex_ph_H2O=(h_H2O_out-h_H2O_ref)-T_dead*(s_H2O_out-s_H2O_ref)
    ex_ph_N2=(h_N2_out-h_N2_ref)-T_dead*(s_N2_out-s_N2_ref)
    ex_ph_O2=(h_O2_out-h_O2_ref)-T_dead*(s_O2_out-s_O2_ref)
    
    #Thermal Exergy w stoichiometric coefficients
    ex_th_NH3_in=NH3_in*ex_ch_NH3
    ex_th_O2_in=O2_in*ex_ch_O2
    ex_th_N2_in=N2_in*ex_ch_N2
    
    ex_th_H2O=H2O_out*(ex_ch_H2Og+ex_ph_H2O)
    ex_th_O2_out=O2_out*(ex_ch_O2+ex_ph_O2)
    ex_th_N2_out=N2_out*(ex_ch_N2+ex_ph_N2)
    
    Ex_in=ex_th_NH3_in+ex_th_O2_in+ex_th_N2_in
    Ex_out=ex_th_H2O+ex_th_O2_out+ex_th_N2_out
    
    Ex_des=Ex_in-Ex_out
    
    #n_ex_ammonia=1-(Ex_des/Ex_in)
    n_ex_comb=1-(Ex_des/Ex_in)
    n_ex_carnot=1-(283.15/T_out)
    
    n_ex_ammonia=n_ex_comb*n_ex_carnot
    
    return n_ex_ammonia

def Ex_Methane(phi,T_dead):
    
    T_ref=T_dead
    f=q.Methane_Comb(phi,T_ref)
    
    T_out=f['T_flame']
    CH4_in=f['CH4_in']
    O2_in=f['O2_in']
    N2_in=f['N2_in']
    CO2_out=f['CO2_out']
    H2O_out=f['H2O_out']
    O2_out=f['O2_out']
    N2_out=f['N2_out']

    
    #Enthalpy and Entropy Out
    h_CO2_out=r.Enth_CO2(T_out)
    h_H2O_out=r.Enth_H2Og(T_out)
    h_N2_out=r.Enth_N2(T_out)
    h_O2_out=r.Enth_O2(T_out)
    
    s_CO2_out=r.Entro_CO2(T_out)
    s_H2O_out=r.Entro_H2Og(T_out)
    s_N2_out=r.Entro_N2(T_out)
    s_O2_out=r.Entro_O2(T_out)    
    
    
    #Enthalpy and Entropy Ref
    h_CO2_ref=r.Enth_CO2(T_ref)
    h_H2O_ref=r.Enth_H2Og(T_ref)
    h_N2_ref=r.Enth_N2(T_ref)
    h_O2_ref=r.Enth_O2(T_ref)
    
    s_CO2_ref=r.Entro_CO2(T_ref)
    s_H2O_ref=r.Entro_H2Og(T_ref)
    s_N2_ref=r.Entro_N2(T_ref)
    s_O2_ref=r.Entro_O2(T_ref)
    
    #Physcial Exergy Out
    ex_ph_CO2=(h_CO2_out-h_CO2_ref)-T_dead*(s_CO2_out-s_CO2_ref)
    ex_ph_H2O=(h_H2O_out-h_H2O_ref)-T_dead*(s_H2O_out-s_H2O_ref)
    ex_ph_N2=(h_N2_out-h_N2_ref)-T_dead*(s_N2_out-s_N2_ref)
    ex_ph_O2=(h_O2_out-h_O2_ref)-T_dead*(s_O2_out-s_O2_ref)
    
    #Thermal Exergy w stoichiometric coefficients
    ex_th_CH4_in=CH4_in*ex_ch_CH4
    ex_th_O2_in=O2_in*ex_ch_O2
    ex_th_N2_in=N2_in*ex_ch_N2
    
    ex_th_CO2=CO2_out*(ex_ch_CO2+ex_ph_CO2)
    ex_th_H2O=H2O_out*(ex_ch_H2Og+ex_ph_H2O)
    ex_th_O2_out=O2_out*(ex_ch_O2+ex_ph_O2)
    ex_th_N2_out=N2_out*(ex_ch_N2+ex_ph_N2)
    
    Ex_in=ex_th_CH4_in+ex_th_O2_in+ex_th_N2_in
    Ex_out=ex_th_CO2+ex_th_H2O+ex_th_O2_out+ex_th_N2_out
    
    Ex_des=Ex_in-Ex_out
    
    #n_ex_methane=1-(Ex_des/Ex_in)
    n_ex_comb=1-(Ex_des/Ex_in)
    n_ex_carnot=1-(283.15/T_out)
    
    n_ex_methane=n_ex_comb*n_ex_carnot     
    
    return n_ex_methane


def Ex_Summary(phi,T_dead):
    n_iron=Ex_Iron(phi,T_dead)
    n_diesel=Ex_Diesel(phi,T_dead)
    n_coal=Ex_Coal(phi,T_dead)
    n_hydrogen=Ex_Hydrogen(phi,T_dead)
    n_ammonia=Ex_Ammonia(phi,T_dead)
    n_methane=Ex_Methane(phi,T_dead)

    print('Ex_Iron:',n_iron)
    print('Ex_Diesel',n_diesel)
    print('Ex_Coal',n_coal)
    print('Ex_Hydrogen',n_hydrogen)
    print('Ex_Ammonia',n_ammonia)
    print('Ex_Methane',n_methane)
    
    return

Ex_Summary(3.432872481,300)