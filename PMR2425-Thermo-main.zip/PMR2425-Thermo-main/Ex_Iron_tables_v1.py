import Combustion_v1 as q
import NISTpoly_v2_H2Omod as r

#Chemical Exergies (kJ/mol)
ex_ch_Fe=374.3
ex_ch_FeO=124.9#111.3
ex_ch_Fe3O4=116.3
ex_ch_Fe2O3=12.4
ex_ch_O2=3.97
ex_ch_N2=0.69
ex_ch_H2=236.09
ex_ch_H2OL=0.9
ex_ch_H2Og=9.5
ex_ch_C=409.87
ex_ch_CO2=19.48
ex_ch_NH3=337.9
ex_ch_CH4=831.2
ex_ch_C12H23=6000#'blah' #*********************FIX*********************



def Ex_Iron(phi,T_dead):
    
    T_ref=T_dead
    a=q.Iron_Comb_Fe3O4(phi,T_ref)
    T_out=a['T_flame']
    Fe_in=a['Fe_in']
    O2_in=a['O2_in']
    N2_in=a['N2_in']
    Fe3O4_out=a['Fe3O4_out']
    O2_out=a['O2_out']
    N2_out=a['N2_out']
    
    #Enthalpy and Entropy Out
    h_Fe3O4_out=r.Enth_Fe3O4(T_out)
    h_N2_out=r.Enth_N2(T_out)
    h_O2_out=r.Enth_O2(T_out)
    
    s_Fe3O4_out=r.Entro_Fe3O4(T_out)
    s_N2_out=r.Entro_N2(T_out)
    s_O2_out=r.Entro_O2(T_out)    
    
    
    #Enthalpy and Entropy Ref
    h_Fe3O4_ref=r.Enth_Fe3O4(T_ref)
    h_N2_ref=r.Enth_N2(T_ref)
    h_O2_ref=r.Enth_O2(T_ref)
    
    s_Fe3O4_ref=r.Entro_Fe3O4(T_ref)
    s_N2_ref=r.Entro_N2(T_ref)
    s_O2_ref=r.Entro_O2(T_ref)
    
    #Physcial Exergy Out
    ex_ph_Fe3O4=(h_Fe3O4_out-h_Fe3O4_ref)-T_dead*(s_Fe3O4_out-s_Fe3O4_ref)
    ex_ph_N2=(h_N2_out-h_N2_ref)-T_dead*(s_N2_out-s_N2_ref)
    ex_ph_O2=(h_O2_out-h_O2_ref)-T_dead*(s_O2_out-s_O2_ref)
    
    #Thermal Exergy w stoichiometric coefficients
    ex_th_Fe_in=Fe_in*ex_ch_Fe
    ex_th_O2_in=O2_in*ex_ch_O2
    ex_th_N2_in=N2_in*ex_ch_N2
    
    ex_th_Fe3O4=Fe3O4_out*(ex_ch_Fe3O4+ex_ph_Fe3O4)
    ex_th_O2_out=O2_out*(ex_ch_O2+ex_ph_O2)
    ex_th_N2_out=N2_out*(ex_ch_N2+ex_ph_N2)
    
    Ex_in=ex_th_Fe_in+ex_th_O2_in+ex_th_N2_in
    Ex_out=ex_th_Fe3O4+ex_th_O2_out+ex_th_N2_out
    
    Ex_des=Ex_in-Ex_out
    
    #n_ex_iron=1-(Ex_des/Ex_in)
    n_ex_comb=1-(Ex_des/Ex_in)
    n_ex_carnot=1-(283.15/T_out)
    
    n_ex_iron=n_ex_comb*n_ex_carnot
    
    #get values for tables
    print(T_out)
    print(Fe_in)
    print(O2_in)
    print(N2_in)
    print(Fe3O4_out)
    print(O2_out)
    print(N2_out)
    print(h_Fe3O4_out)
    print(h_O2_out)
    print(h_N2_out)
    print(h_Fe3O4_ref)
    print(h_O2_ref)
    print(h_N2_ref)
    print(s_Fe3O4_out)
    print(s_O2_out)
    print(s_N2_out)
    print(s_Fe3O4_ref)
    print(s_O2_ref)
    print(s_N2_ref)
    print(ex_ch_Fe)
    print(ex_ch_O2)
    print(ex_ch_N2)
    print(ex_ch_Fe3O4)
    print(ex_ch_O2)
    print(ex_ch_N2)
    
    return n_ex_iron

Ex_Iron(3.432872481,300)